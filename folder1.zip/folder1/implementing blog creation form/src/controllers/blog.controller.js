export const renderBlogForm = (req, res) => {
  res.render("createBlog");
};
