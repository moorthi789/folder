import app from "./index.js";

app.listen(3000, () => {
  console.log("app is listening at PORT 3000");
});
