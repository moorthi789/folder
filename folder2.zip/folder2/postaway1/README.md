# Postaway
Develop an API for a social media application with a user friendly interface to register and authenticate users , create a post and to like and comment on that post.
