import app from "./index.js";

app.listen(5000, () => {
  console.log("Server is listening at port 5000");
});
